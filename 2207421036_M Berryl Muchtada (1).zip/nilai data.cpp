#include <iostream>
using namespace std;
// menentukan nilai data
int main() {
  float nilai;
	
  cout << "Masukan Nilai  :";
  cin>> nilai;

if(nilai >=81){
cout<<"nilai kamu   : A"<<endl;
  	
  }
  
  
  	else if(nilai >=78){
cout<<"nilai kamu   : B"<<endl;
  	
  } 
  
  	else if(nilai >=67){
cout<<"nilai kamu   : C"<<endl;
  	
  } 
  
  	else if(nilai >=51){
cout<<"nilai kamu  : D"<<endl;
  	
  } 
  	
	else if(nilai <51){
  	cout<<"nilai kamu   : E"<<endl;
  	
  } 
  	else{
  		cout<<"PROGRAM SELESAI";
  		
	  }
  return 0;
}