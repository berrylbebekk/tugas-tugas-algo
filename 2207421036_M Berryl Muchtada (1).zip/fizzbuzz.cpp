#include<iostream>
using namespace std;
//fizzbuzz
int main(){
	
	int angka;
	int x;
	
	cout<<"FIZZ BUZZ\n";
	cout<<"\nMasukan angka : ";
	cin>>angka;
	
	for(x=1; x <= angka; x++){
	if (x % 3 == 0 && x % 5 == 0){
	cout<<"Fizz Buzz"<<endl;
	}
	else if (x % 3 == 0){
	cout<<"Fizz"<<endl;
	}
	else if (x % 5 == 0){
	cout<<"Buzz"<<endl;
	}else{
	cout<<x<<endl;
	}
	
	}
	return 0;
}