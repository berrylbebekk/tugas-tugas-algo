#include<iostream>
using namespace std;
// menentukan bilangan ganjil genap dan prima
int main(){
	
		int A, B, C;
	B = 0;
	
	cout<<"GANJIL, GENAP, DAN PRIMA\n";
	cout<<"\nMasukan bilangan : ";
	cin>>C;

	for(A = 1; A<=C; A++){
		if(C % A == 0){
			B++;
		}
	}
	
	cout<<"Angka "<<C<<" ";
	if(B == 2){
		cout<<"Bilangan Prima";
	}else{
		cout<<"Bukan Bilangan Prima";
	}
	
	if(C % 2 == 0){
		cout<<"\nAngka "<<C<<" Bilangan Genap";
	}else{
		cout<<"\nAngka "<<C<<" Bilangan Ganjil";
	}
	
	return 0;
}