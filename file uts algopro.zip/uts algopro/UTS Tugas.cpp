#include <iostream>
using namespace std;

void sk(){
    cout << "Berlaku weekend, weekdays, & public holiday" << endl;
    cout << "(Sabtu, Minggu, Senin - Jumat dan Hari Libur Nasional dngan minimal reservasi 25 orang)" << endl << endl;
    cout << "Harga Safari Trek Group sudah termasuk:\nKegiatan Hiking, Wahana Outbound, Pemandu, SFC Lunch Box, dan Snack Box" << endl;
}

int main(){
    int rekreasi;
    int total;
    int kali;
    bool domestik = false;
    bool internasional = false;
    cout << "Selamat datang di pembelian tiket Taman Safari Bogor" << endl;
    cout << "----------------------------------------------------" << endl;
    cout << "Silahkan pilih jenis rekreasi di Taman Safari Bogor:" << endl << endl;
    cout << "1. Safari Trek & Outbound" << endl;
    cout << "2. Safari Siang Istana Panda" << endl << endl;
    cout << "Masukkan pilihan : ";
    for(;;){
        cin >> rekreasi;
        if(rekreasi == 1 ){
            break;
        }
        else if(rekreasi == 2){
            break;
        }
        else{
            cout << "Angka yang dimasukkan tidak termasuk ke dalam pilihan" << endl << endl;
            cout << "Masukkan pilihan : ";
            continue;
        }
    }
    switch(rekreasi)
    {
    case 1:
        //Safari Trek & Outbound
        int trek;
        cout << "Pembelian tiket Safari Trek & Outbound" << endl;
        cout << "Group: Rp150.000/orang (Minimal 25 orang)" << endl << endl;
        cout << "Tekan 1 untuk membaca syarat dan ketentuan" << endl;
        cout << "Tekan 2 untuk membeli tiket" << endl;
        cout << endl << "Masukkan pilihan : ";
        for(;;){
            cin >> trek;
            if(trek == 1){
                sk();
                cout << endl << "Masukkan pilihan : ";
                continue;
            }
            else if(trek == 2){
                cout << "Masukkan jumlah pembelian (Minimal 25) : ";
                for(;;){
                    cin >> kali;
                    if(kali < 25){
                        cout << "Jumlah kurang dari 25" << endl << endl;
                        cout << "Masukkan jumlah pembelian : ";
                        continue;
                    }
                    else{
                        total = 150000;
                        break;
                    }
                }
            break;
            }
            else{
                cout << "Angka yang dimasukkan tidak termasuk ke dalam pilihan" << endl << endl;
                cout << "Masukkan pilihan : ";
                continue;
            }
        }
        break;

    case 2:
        //Safari Siang
        int trekSiang;
        int lokasi;
        cout << "Pembelian tiket Safari Siang Istana Panda" << endl;
        cout << "Anda dari mana?" << endl;
        cout << "Tekan 1 untuk Domestik" << endl;
        cout << "Tekan 2 untuk Internasional" << endl;
        cout << endl << "Masukkan pilihan : ";
        for(;;){
            cin >> lokasi;
            if(lokasi == 1){
                domestik = true;
                break;
            }
            else if(lokasi == 2){
                internasional = true;
                break;
            }
            else{
                cout << "Angka yang dimasukkan tidak termasuk ke dalam pilihan" << endl << endl;
                cout << "Masukkan pilihan : ";
                continue;
            }
        }
        cout << endl << "Pilih jenis tiket Safari Siang Istana Panda" << endl << endl;
        cout << "Tekan 1 untuk weekday" << endl;
        cout << "Tekan 2 untuk weekend" << endl;
        cout << endl << "Masukkan pilihan : ";
        for(;;){
            cin >> trekSiang;
            if(trekSiang == 1){
                //weekday
                if(domestik){
                    cout << "Masukkan jumlah tiket: ";
                    cin >> kali;
                    total = 230000;
                }
                else if(internasional){
                    cout << "Masukkan jumlah tiket: ";
                    cin >> kali;
                    total = 230000;
                }
                break;
            }
            else if(trekSiang == 2){
                //weekend
                 if(domestik){
                    cout << "Masukkan jumlah tiket: ";
                    cin >> kali;
                    total = 225000;
                }
                else if(internasional){
                    cout << "Masukkan jumlah tiket: ";
                    cin >> kali;
                    total = 400000;
                }
                break;
                }
            else{
                cout << "Angka yang dimasukkan tidak termasuk ke dalam pilihan" << endl << endl;
                cout << "Masukkan pilihan : ";
                continue;
            }
        }
        break;
    }
cout << endl << "Harga tiket anda : " << total*kali;
}

