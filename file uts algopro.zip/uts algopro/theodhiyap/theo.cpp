#include <iostream>
using namespace std;

int main(){	
	
	//masukan tipe data dan inputannya
	string harga,tiket,jenis,syarat;
	int umur;
	
	cout<<"SAFARI MALAM"<<endl<<endl;
	cout<<"FASILITAS: SAFARI JOURNEY - 2 PERTUNJUKAN EDUKASI - 24 WAHANA PERMAINAN"<<endl<<endl;


	cout<<"DOMESTIC/INTERNASIONAL"<<endl;//jenis tiket
	cout<<"SILAHKAN PILIH : "<<endl<<endl;//pilih jenis tiket yang anda mau
	cin>>jenis;
	

		if (jenis=="DOMESTIC"){
		cout<<"MASUKAN UMUR : ";
		cin>>umur;
		if (umur>6 ){
			cout<<"Tarif : 180.000";
		}else if (umur <=5){
			cout<<"Tarif : 160.000";
		//jika anda memilih domestic lalu masukan umur jika umur diatas 6 maka tiket 180.000, jika umur dibawah 3 tahun harga tiket 160.000		
		}	
		
		else if (jenis=="INTERNASIONAL"){
		cout<<"MASUKAN UMUR : ";
		cin>>umur;
		if (umur>6 ){
			cout<<"Tarif : 350.000";
		}else if (umur <=5){
			cout<<"Tarif : 300.000";
				
		}	
		////jika anda memilih Internasional lalu masukan umur jika umur diatas 6 maka tiket 350.000, jika umur dibawah 3 tahun harga tiket 300.000		
		
		
	

}
}
}


