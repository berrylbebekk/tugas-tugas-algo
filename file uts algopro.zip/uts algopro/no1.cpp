#include <iostream>
#include <cstdlib>
#include <conio.h>
#include <algorithm>
#define nl "\n"

#ifdef _WIN32
	#define clr "cls"
#else //In any other OS
	#define clr "clear"
#endif

using namespace std;

int main(int argc, char* argv[]) {
	int num_quest;
	
			string day;
			int pax;
			char reservation, deposit, join;
			
			string msg;
			bool ok = 0; // tanda untuk kesalahan
			bool choice = 0; // mendaftar VVIP atau tidak.
			long long total_n1 = 0;
			
			int choice_n2;
			int age;
			int many;
			int total_n2 = 0;
	
	cout << "Soal nomor? (1/2): "; cin >> num_quest;
	cout << nl;
	switch(num_quest) {
		case 1:
		
			cout << "===== [CEK HARGA BEHIND THE SCENE TOUR] =====" << nl;
		
			cout << "Hari kunjungan (Senin-Selasa)\t\t\t: "; cin >> day; // input hari kunjungan
			if((day != "Senin") && (day != "Selasa") && (day != "Rabu") && (day != "Kamis") && (day != "Jumat")) {
				ok  = 0;
				return 0; // keluar dari program karena tidak dapat ikut program
			}
			else {
				cout << "Beli untuk berapa pax\t\t\t\t: "; cin >> pax; 
				if(pax < 5 || pax > 15) {
					ok = 0;
					return 0; // jika salah langsung keluar.
				}
				else {
					total_n1 = 1000000 * pax;
					ok = 1;
				}
			}
			
			if(!ok) {
				msg = "Maaf! Anda tidak dapat mengikuti program";
			}
			else {
				msg = "Selamat! Anda dapat mengikuti program";
			}

			cout << nl;
			cout << "=======================================" << nl;
			cout << msg << nl;
			cout << "Total bayar: " << "Rp" << total_n1 << nl;
			cout << "=======================================" << nl;
			break;
		case 2:
			cout << "===== [CEK HARGA TIKET SAFARI MALAM] =====" << nl;
			
			cout << "Pilihan Tiket: " << nl;
			cout << "1. Domestic" << nl;
			cout << "2. Internasional" << nl;
			cout << "Pilihan Anda? (1/2): "; cin >> choice_n2;
			switch(choice_n2){
				case 1:
					cout << "Masukkan umur Anda: "; cin >> age;
					cout << "Beli berapa tiket?: "; cin >> many;
					if(age <= 5) {
						total_n2 += (160000 * many);
					}
					else if(age > 6) {
						total_n2 += (180000 * many);
					}
					cout << nl;
					cout << "=======================================" << nl;
					cout << "Total harga: " << "Rp" << total_n2 << nl;
					cout << "=======================================" << nl;
					break;
				case 2:
					cout << "Masukkan umur Anda: "; cin >> age;
					cout << "Beli berapa tiket?: "; cin >> many;
					if(age <= 5) {
						total_n2 += (350000 * many);
					}
					else if(age > 6) {
						total_n2 += (300000 * many);
					}
					
					cout << "=======================================" << nl;
					cout << "Total harga: " << "Rp" << total_n2 << nl;
					cout << "=======================================" << nl;
					
					break;
				default:
					cerr << "[ERROR]: Hanya terdapat 2 pilihan!!" << nl;
					return 0;
			}
			break;
		default:
			cerr << "[ERROR]: Soal hanya 2 nomor!!" << nl;
	}
	
	getch();
	return 0;
}
