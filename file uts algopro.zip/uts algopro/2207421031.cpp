#include <iostream>
using namespace std;

int main(){
	cout << "=====================================\n";
	cout << "     TIKET SAFARI TREK & OUTBOUND    \n";
	cout << "=====================================\n\n";
	// membuat variabel 
	int umur, tiket, orang, H_grup=150000, domestik_w6=230000, domestik_w5=200000, intr_wh5=350000;
	int domestik_wh6=255000, domestik_wh5=225000, intr_w6=400000, intr_w5=350000, intr_wh6=400000;
	string reservasi, j_tiket, hari;
	// menanyakan hari kunjungan dengan menggunakan input 
	cout << "Pilih hari kunjungan (senin-minggu/holiday) :";
	cin >> hari;
	if (hari == "senin"||hari=="selasa"||hari=="rabu"||hari=="kamis"||hari=="jumat"){
		cout << "Jenis reservasi (individu/group) :";
		cin >> reservasi;
		if (reservasi == "group"){
			cout << "Jumlah reservasi :";
			cin >> orang;
			if (orang < 25){
				cout << "---------------------------------------\n";
				cout << "Jumlah minimal reservasi untuk group sebanyak 25 orang";
			}
			else if (orang >= 25){
				cout << "---------------------------------------\n";
				cout << "Harga tiket anda sebesar Rp."<<H_grup*orang<<"";
			}
		}
		else if (reservasi == "individu"){
			cout << "jenis tiket (domestik/internasional) :";
			cin >> j_tiket;
			if (j_tiket == "domestik"){
				cout << "Usia anda :";
				cin >> umur;
				if (umur <= 5){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<domestik_w5<<"";
				}
				else if (umur >= 6){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<domestik_w6<<"";
				}
			}
			else if (j_tiket == "internasional"){
				cout << "Usia anda :";
				cin >> umur;
				if (umur <= 5){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<intr_w5<<"";
				}
				else if (umur >= 6){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<intr_w6<<"";
				}
			}
		}
	}
	else if (hari == "sabtu"||hari == "minggu"||hari == "holiday"){
		cout << "Jenis reservasi (individu/group) :";
		cin >> reservasi;
		if (reservasi == "group"){
			cout << "Jumlah reservasi :";
			cin >> orang;
			if (orang < 25){
				cout << "---------------------------------------\n";
				cout << "Jumlah minimal reservasi untuk group sebanyak 25 orang!";
			}
			else if (orang >= 25){
				cout << "---------------------------------------\n";
				cout << "Harga tiket anda sebesar Rp."<<H_grup*orang<<"";
			}
		}
		else if (reservasi == "individu"){
			cout << "jenis tiket (domestik/internasional) :";
			cin >> j_tiket;
			if (j_tiket == "domestik"){
				cout << "Usia anda :";
				cin >> umur;
				if (umur <= 5){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<domestik_wh5<<"";
				}
				else if (umur >= 6){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<domestik_wh6<<"";
				}
			}
			else if (j_tiket == "internasional"){
				cout << "Usia anda :";
				cin >> umur;
				if (umur <= 5){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<intr_wh5<<"";
				}
				else if (umur >= 6){
					cout << "---------------------------------------\n";
					cout << "Harga tiket anda sebesar Rp."<<intr_wh6<<"";
				}
			}
		}
	}
	
	return 0;
}