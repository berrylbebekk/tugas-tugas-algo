/* 
	Nama	: Cornelius Yuli Rosdianto
	NIM		: 2207421059
	Kelas	: TMJ 1B
*/


#include <iostream>
#include <conio.h>
using namespace std;

int main ()
{

	
	string repeat,lokal, libur, day,error="\nINVALID INPUT\n";
	int tiket, total, solo, anak, dewasa, child, adult;
	
	do {
		
		system("cls");
		
		cout<<"\t\t ### TIKET SAFARI TREK DAN OUTBOUND ###\n\n\n"; 	//JUDUL
		

		cout<<"Tiket untuk hari apa? (Senin-Minggu)\t\t: ";
			cin>>day;
		if (day!="senin" && day!="selasa"&&day!="rabu"&&day!="kamis"&&day!="jumat" && day!="sabtu" && day!="minggu"&&libur!="n"&&libur!="y")
	 			{
				cout<<error;
				cout<<"Mohon ketik dengan benar & tanpa menggunakan kapital";		//memilih hari selain hari yang ada
				getch();
				return 0;
				}			
		else{}
		
		cout<<"Apakah pada hari itu ada libut nasional (y/n)\t: ";
			cin>>libur;
			if(libur!="y" && libur!="n" ) {	cout<<error; return 0;}	//memilih selain pilihan
			else {}		
		cout<<"Apakah untuk domestic? (y/n)\t\t\t: ";
			cin>>lokal;	
			if(lokal!="y" && lokal!="n" ) {	cout<<error; return 0;}	 //memilih selain pilihan
			else {}			
		cout<<"\nJenis tiket untuk : \n";
		cout<<"1. perorangan\n";
		cout<<"2. group\n";
		cout<<"Silahkan masukan pilihan anda (1-2) \t: ";
			cin>>solo;	
			
		
			
if(solo==1){

		if (day!="senin" && day!="selasa"&&day!="rabu"&&day!="kamis"&&day!="jumat" && day!="sabtu" && day!="minggu"&&libur!="n"&&libur!="y")
	 			{
				cout<<error;
				cout<<"Mohon ketik dengan benar & tanpa menggunakan kapital";		//memilih hari selain hari yang ada
				getch();
				return 0;
				}	
	
		else if (day=="sabtu"||day=="minggu"||libur=="y") {
			if(lokal=="y"){
				cout<<"Jumlah tiket untuk umur <5 tahun \t: ";
					cin>>child;
				cout<<" Jumlah tiket untuk umur >5 tahun \t: ";
					cin>>adult;	
						
				anak=220*child;
				dewasa=255*adult;		
				total=anak+dewasa;	//TOTAL HARGA TIKET						
							
			}else if (lokal=="n"){
				cout<<"Jumlah tiket untuk umur <5 tahun \t: ";
					cin>>child;
				cout<<"Jumlah tiket untuk umur >5 tahun \t: ";
					cin>>adult;	
				anak=350*child;		//harga tiket anak
				dewasa=400*adult;		//harga tiket dewasa
				total=anak+dewasa;	
			}else {cout<<error;}
			
	}else{
			if(lokal=="y"){
				cout<<"Jumlah tiket untuk umur <5 tahun \t: ";
					cin>>child;
				cout<<" Jumlah tiket untuk umur >5 tahun \t: ";
					cin>>adult;	
						
				anak=200*child;
				dewasa=230*adult;		
				total=anak+dewasa;	//TOTAL HARGA TIKET						
							
			}else if (lokal=="n"){
				cout<<"Jumlah tiket untuk umur <5 tahun \t: ";
					cin>>child;
				cout<<" Jumlah tiket untuk umur >5 tahun \t: ";
					cin>>adult;	
				anak=350*child;		//harga tiket anak
				dewasa=400*adult;		//harga tiket dewasa
				total=anak+dewasa;	
			}else {cout<<error;}
		}
	 
}else if(solo==2) {
			
		cout<<"Harga\t: Rp 150.000/orang (minimal reservsi 25 orang)\n\n ";
		cout<<"Harga tiket Safari Trek Group sudah termaksud : \n";
		cout<<"- Kegiatan Hiking (menyusuri Hutan Gunung Gede Pangrogo)\n";
		cout<<"- Wahana Outbound \n";
		cout<<"- Pemandu \n";	
		cout<<"- SFC Lunch Box (Fried Chicken, Rice, Tek=h Kotak)\n";
		cout<<"- Snack Box\n\n\n\n";
		
		cout<<"Jumlah tiket yang ingin dipesan : ";
			cin>>tiket;					//input jumlah tiket
			
		total=tiket*250;	
			
		if(tiket<25) {
			cout<<"\n\nMinimal pembelian tiket sebanyak 25\n Silahkan memesan ulang";
			return 0;   //mengakhiri program jika pembelian tiket kurang dari 25
		}else {}
		
		
}else {cout<<error; return 0; getch();}

			
		cout<<"\n\n\n";
		cout<<"=========================================================\n\n";
		cout<<"Harga yang perlu dibayarkan = Rp "<<total<<".000,-\n\n";							//kesimpulan
		cout<<"==========================================================\n\n";
		
	
		
		cout<<"Apakah anda ingin menginput ulang? : ";
		cin>>repeat;					//loop untuk input ulang
	
		}while(repeat=="y");

		return 0;
		getch();		//agar program tidak tertutup
			
}
	
	