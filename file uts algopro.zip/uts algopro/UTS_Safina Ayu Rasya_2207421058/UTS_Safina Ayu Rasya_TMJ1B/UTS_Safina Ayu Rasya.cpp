#include <iostream>
using namespace std;

int main (){ // mengandung semua koding yang akan dibuat
	double jenis, jumlah; // variabel menggunakan double karena di cin akan diminta angka (dan lebih mudah diatur)
	double umur1, umur2, pengunjung;
	
	cout << "SELAMAT DATANG DI TAMAN SAFARI INDONESIA" << endl; // header kalkulator tiket
	cout << endl;
	
	cout << "Silakan pilih jenis tiket !" << endl;
	cout << "1. Behind the Scene Tour" << endl;
	cout << "2. Safari Malam" << endl;
	cout << endl;
	cout << "Tiket yang dipilih (1/2) = "; // jika dipilih 1, akan dibawa ke petunjuk selanjutnya behind the scene tour
		cin >> jenis; // jika dipilih 2, akan dibawa ke petunjuk selanjutnya safari malam
	
	if (jenis == 1){ // kurung kurawal condition if di awal dan akhir mengandung semua command dlm sistem kalkulator tiket
		cout << "Behind the Scene Tour (VVIP)" << endl << endl; // sub header
		cout << "Syarat & Ketentuan" << endl;
		cout << "- Hanya berlaku hari Senin - Jumat" << endl;
		cout << "- Minimal 5 pax. Maksimal 15 pax" << endl;
		cout << "- Harus melakukan reservasi dan deposit terlebih dahulu" << endl << endl;
		
		cout << "Jumlah pax yang dibeli = ";
			cin >> jumlah;
		
		if (jumlah < 5) {cout << "Minimal pembelian 5 pax!";} // jika di jumlah pax memasukkan angka < 5, muncul peringatan
		else if (jumlah > 15) {cout << "Maksimal pembelian 15 pax!";} // jika di jumlah pax memasukkan angka > 15, muncul peringatan
		else if (jumlah >= 5 && jumlah <= 15){ // jika di jumlah pax memasukkan jumlah tiket 5 sampai 15, muncul total harga tiket
			cout << "Harga yang harus dibayar = " << jumlah; cout << " juta"; // memakai cout "juta" agar lebih mudah dilihat
		}
	}
		
	else if (jenis == 2){ // kurung kurawal condition if di awal dan akhir mengandung semua command dlm sistem kalkulator tiket
		cout << "Safari Malam" << endl << endl; // sub header
		cout << "Fasilitas : Safari Journey - 2 Pertunjukan Edukasi - 24 Wahana Permainan" << endl;
		cout << "Pilih jenis pengunjung !" << endl;
		cout << "1. Domestik" << endl; // ketentuan pengunjung domestik
		cout << "> 6 tahun : Rp 180.000,-" << endl;
		cout << "< 5 tahun : Rp 160.000,-" << endl << endl;
		
		cout << "2. Internasional" << endl; // ketentuan pengunjung internasional
		cout << "> 6 yo : Rp 350.000,-" << endl;
		cout << "< 5 yo : Rp 300.000,-" << endl << endl;
		
		cout << "Jenis pengunjung (1/2) = ";
			cin >> pengunjung;
		cout << "Jumlah pengunjung > 6 tahun = ";
			cin >> umur1;
		cout << "Jumlah pengunjung < 5 tahun = ";
			cin >> umur2;
		
		if (pengunjung == 1){ // condition if jika pengunjung domestik
			cout << "Harga tiket yang dibayar = " << (umur1*180000) + (umur2*160000); 
		}
		else if (pengunjung == 2){ // condition if jika pengunjung internasional
			cout << "Harga tiket yang dibayar = " << (umur1*350000) + (umur2*300000); 
		}
		
	}
		


	return 0;
}
