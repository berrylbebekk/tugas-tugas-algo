#include<iostream>
using namespace std;

int main(){
	string hari, reservasi;
	int tiket2;
	float tiket, pax, safari;
	
	cout<<"LIST TIKET"<<endl;
	cout<<"1. BEHIND THE SCENE TOUR"<<endl;
	cout<<"2. SAFARI MALAM"<<endl;
	
	cout<<"MAU BELI TIKET APAKAH ANDA :";
	cin>>tiket;
	
	if (tiket == 1){
		cout<<"PROGRAM BEHIND SCENE TOUR HARGA VVIP Rp.1.000.000 pax"<<endl;
		cout<<"Harus melakukan reservasi & deposit terlebih dahulu"<<endl;
		cout<<"Minimal 5 pax Maksimal 15 pax"<<endl;
		cout<<"========FASILITAS========"<<endl;
		cout<<"- Mengunjungi Rumah sakit satwa, ruang nursery, ruang pathologi, exhibit area, pusat penangkaran gajah, pusat penangkaran harimau & GENOME RESORCE BANK "<<endl;
		cout<<"- Safari Journey + pemandu + tiket terusan panda"<<endl;
		cout<<"- makan pilihan makan siang (termasuk jus dan kopi) + snack box"<<endl;
		cout<<"- Reservasi tempat duduk di Animal Show"<<endl;
		cout<<"- disediakan tempat parkir"<<endl;	
	}else if (tiket == 2){
		cout<<"PROGRAM SAFARI MALAM"<<endl;
		cout<<" FASILITAS : Safari Journey, 2 Pertunjukan Edukasi, 24 Wahana Permainan"<<endl;
		cout<<" DOMESTIC"<<endl;
		cout<<" >6 tahun Rp.180.000"<<endl;
		cout<<" <5 tahun Rp.160.000"<<endl;
		cout<<" INTERNATIONAL"<<endl;
		cout<<" >6 years old Rp.350.000"<<endl;
		cout<<" <5 years old Rp.300.000"<<endl;
	}
	cout<<"PILIHAN ANDA ADALAH "<<tiket<<endl;
	
	cout<<"PILIH HARI KEDATANGAN : ";
	cin>>hari;
	
	if (hari=="senin"||hari=="selasa"||hari=="rabu"||hari=="kamis"||hari=="jumaat"){
		cout<<"TIKET SAFARI MALAM & BEHIND THE SCENE TOUR TERSEDIA"<<endl;
	}
	else if (hari == "sabtu"||hari == "minggu"){
		cout<<"TIKET SAFARI MALAM TERSEDIA "<<endl;
		cout<<"TIKET BEHIND SCENE TOUR TIDAK TERSEDIA"<<endl;
	}
	
	cout<<"========================================================"<<endl;
	cout<<"1. BEHIND THE SCENE TOUR"<<endl;
	cout<<"2. SAFARI MALAM"<<endl;
	cout<<"MAU BELI TIKET APAKAH ANDA :";
	cin>>tiket2;
	
	if (tiket2 == 1){
	 cout<<"Apakah anda sudah melakukan Reservasi dan deposit (sudah / belum) :";
	 cin>>reservasi;
	 if (reservasi == "sudah"){
	 	cout<<"ANDA DI PERBOLEHKAN BELI TIKET"<<endl;	
	 }else if (reservasi == "belum")
	 	cout<<"ANDA TIDAK DI PERBOLEHKAN BELI TIKET"<<endl;
	 	cout<<"==========================================================="<<endl;
	 cout<<"MINIMAL 5 PAX MAKSIMAL 15 PAX"<<endl;
	 cout<<"MAU BELI BERAPA PAX :";
	 cin>>pax;
	 if (pax < 5)
	 cout<<"Minimal 5 pax"<<endl;
	}else if (pax >=5 && pax<=15){
	cout<<"Harga 1 pax nya Rp.1.000.000"<<endl;
	}
	else if (pax > 15){
		cout<<"MAKSIMAL 15 PAX"<<endl;
	}
	else if (tiket == 2)
	 cout<<"1. domestic / 2. international :";
	 cin>>safari;
	 if (safari == 1){
	 	cout<<">6 tahun Rp.180.000"<<endl;
	 	cout<<"<5 tahun Rp.160.000"<<endl;
	 }else if (safari == 2){
	 	cout<<">6 tahun Rp.350.000"<<endl;
	 	cout<<"<5 tahun Rp.300.000"<<endl;
	 }
}