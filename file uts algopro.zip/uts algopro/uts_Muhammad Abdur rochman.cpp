#include <iostream>
using namespace std;
//Muhammad Abdur Rochman TMJ 1B 2207421045
int main(){
	string hari;
	float jenis, tiket, weekday, weekend, bayar;
	
	cout<<"===============================================\n";
	cout<<"Tarif Harga Safari Trek & Outbound Group\n";
	cout<<"===============================================\n";
	
	cout<<"Jenis tiket yang ingin di beli : \n";
	cout<<"1. Group (Minimal 25 orang)\n";
	cout<<"2. Perorangan\n";
	cout<<"pilih salah satu isi dengan angka : ";
	cin>>jenis;
	
	if (jenis==1){ 
		cout<<"pilih hari kedatangan anda : ";
		cin>>hari;
		cout<<"Harikedatangan anda adalah hari "<<hari<<endl;
		cout<<"=================================================================\n";
		cout<<"Fasilitas Safari trek group sudah termasuk : \n";
		cout<<"Kegiatan Hiking (menyisir hutan Gunung Gede Pangrango)\n";
		cout<<"Wahana Outbound, Pemandu, SFC Lunch Box(Fried Chiken, Rice, teh kotak) dan Snack Box\n";
		cout<<"=================================================================\n";
	
cout<<"berapa tiket yang akan anda beli tulis dengan angka : ";
cin>>tiket;

bayar = tiket*150000;

cout<<"harga yang harus anda bayar adalah "<<bayar; 
		
}
}
	
	
		
	
		

	
		
	



