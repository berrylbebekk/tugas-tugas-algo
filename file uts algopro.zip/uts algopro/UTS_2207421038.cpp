#include<iostream>
using namespace std;

int main(){
	//BEHIND THE SCENE TOUR
	
	int pax = 1000000, jumlah, bayar;
	string hari, reservasi;
	
	cout<<"BEHIND THE SCENE TOUR"<<endl;
	cout<<"================================================================================="<<endl;
	cout<<"FASILITAS"<<endl;
	cout<<"- Mengunjungi Rumah Sakit Satwa, Ruang Nursery, Ruang Pathologi, exhibit Area"<<endl;
	cout<<"  Pusat Penangkaran Gajah, Pusat Penangkaran Harimau & genome Resource Bank"<<endl;
	cout<<"- Safari Journey + pemandu + Tiket Terusan Panda"<<endl;
	cout<<"- Makan Pilihan Makan Siang (termasuk jus atau kopi) + Snack Box"<<endl;
	cout<<"- Reservasi Tempat Dududk di Animal Show"<<endl;
	cout<<"- Disediakan tempat Parkir"<<endl;
	
	cout<<"HARI KEDATANGAN ANDA : ";
	cin>>hari;
	
	cout<<"BERAPA PAX YANG INGIN ANDA BELI? :";
	cin>>jumlah;
	
	cout<<"APA ANDA SUDAH MELAKUKAN RESERVASI DAN DEPOSIT ? : ";
	cin>>reservasi;
	
	if (hari=="sabtu"||hari=="minggu"){
		cout<<"Program Behind the scene hanya berlaku pada hari senin-jumat!";
	}else if (jumlah<5&&jumlah>15){
		cout<<"Anda harus membeli minimal 5 pax dan maksmal 15 pax!";
	}else if (reservasi == "belum"){
		cout<<"silahkan lakukan reservasi dan deposit terlebih dahulu";
	}else {
		bayar = jumlah*pax;
		cout<<"Anda harus membayar sebesar Rp. "<<bayar<<endl<<endl;
	}
	//HARGA TIKET MASUK SAFARI MALAM
	
	string tiket;
	int umur;
	
	cout<<"Harga Tiket Masuk safari Malam"<<endl;
	cout<<"============================================="<<endl;
	cout<<"Fasilitas : Safari Journey - 2 Pertunjukan Edukasi - 24 wahana Permainan"<<endl;
	cout<<"Asal anda (domestic/international) : ";
	cin>>tiket;
	if (tiket=="domestic"){
		cout<<"Masukan Umur anda : ";
		cin>>umur;
		if(umur>6){
			cout<<"Harga Tiket : Rp. 180.0000,-";
		}else if(umur<5){
			cout<<"Harga Tiket : Rp. 160.000,-";
		}
	}else if (tiket=="international"){
		cout<<"Masukan Umur anda : ";
		cin>>umur;
		if(umur>6){
			cout<<"Harga Tiket : Rp. 350.000,-";
		}else if(umur<5){
			cout<<"Harga Tiket : Rp. 300.000,-";
		}}}
