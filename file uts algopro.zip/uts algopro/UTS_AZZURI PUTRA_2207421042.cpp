#include <iostream>
#include <cmath>
using namespace std;

int main() {
	int jmltiket1, pilihan, usia, jmltiket2, soalno;
	cout<<"SOAL UTS NOMOR (1/2): ";
	cin>>soalno;

	switch (soalno) {
		//SOAL NOMOR 1
		case 1:
		cout<<"PROGRAM BEHIND THE SCENE TOUR\n\n";
		cout<<"syarat dan ketentuan: \n";
		cout<<"1) hanya berlaku hari senin s/d jumat\n";
		cout<<"2) minimal 5 pax dan maksimal 15 pax\n";
		cout<<"3) harus melakukan reservasi dan deposit terlebih dulu\n\n";
		cout<<"fasilitas:\n";
		cout<<"1) mengunjungi rumah sakit satwa, ruang nursery, ruang patologi, exhibit arena, \n";
		cout<<"   pusat penangkaran gajah, pusat penangkaran harimau dan genome resource bank\n";
		cout<<"2) safari journey + pemandu + tiket terusan panda\n";
		cout<<"3) makan pilihan makan siang (termasuk jus atau kopi) + snack box\n";
		cout<<"4) reservasi tempat duduk di animal show\n";
		cout<<"5) disediakan tempat parkir\n";
		cout<<"\nJUMLAH TIKET: ";
		cin>>jmltiket1;
		if (jmltiket1>15) {
			cout <<"maksimal pemesanan 15 tiket";
		} else if (jmltiket1 > 5) {
			cout<<"TOTAL HARGA: "<<1000000*jmltiket1;
		} else {
			cout<<"minimal pemesanan 5 tiket";
		}
			break;
		
		//SOAL NOMOR 2
		case (2):
		cout<<"\n\nPROGRAM HARGA TIKET MASUK SAFARI MALAM\n\n";
		cout<<"PILIHAN PAKET: \n";
		cout<<" 1) domestic    2) international\n\n";
		cout<<"PILIH PAKET (1/2): ";
		cin>>pilihan;
		if (pilihan == 1) {
			cout<<"masukkan usia anda: ";
			cin>>usia;
			if (usia > 6) {
				cout<<"jumlah pemesanan tiket: ";
				cin>>jmltiket2;
				cout<<"tarif tiket: "<<180000*jmltiket2;
			} else if (usia == 5 or usia ==6){
					cout<<"hanya tersedia untuk lebih dari 6 tahun dan kurang dari 5 tahun";
			} else if (usia < 5) {
				cout<<"jumlah pemesanan tiket: ";
				cin>>jmltiket2;
				cout<<"tarif tiket: "<<160000*jmltiket2;
			} 
		} else if (pilihan == 2) {
			cout<<"masukkan usia anda: ";
			cin>>usia;
			if (usia > 6) {
				cout<<"jumlah pemesanan tiket: ";
				cin>>jmltiket2;
				cout<<"tarif tiket: "<<350000*jmltiket2;
			} else if (usia < 5) {
				cout<<"jumlah pemesanan tiket: ";
				cin>>jmltiket2;
				cout<<"tarif tiket: "<<300000*jmltiket2;
			} else if (usia == 5 or usia ==6) {
				cout<<"hanya tersedia untuk lebih dari 6 tahun dan kurang dari 5 tahun";
			}
			
		else {
			cout<<"pilih antara 1 atau 2. JANGAN KEDUANYA";
		}
			break;
	}
}
	
	return 0;
}
