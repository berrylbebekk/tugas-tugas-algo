#include <iostream>
using namespace std;

int main(){
	//Hari Tiket
	int hari, harga, tiket, pembeli, jumlah;
	
	cout<<"HARGA TIKET SAFARI TREK DAN OUTBOUND"<<endl;
	cout<<"===================================="<<endl;
	cout<<"Silahkan pilih hari anda"<<endl;
	cout<<"1. Weekday \n2. Weekend & Public Holiday"<<endl;
	cout<<"Pilih 1 atau 2 : ";
	cin>>hari;
	cout<<endl;
	
	//Hari weekday
	 switch(hari){
	 	case 1 :
			cout<<endl;
			cout<<"================================================"<<endl;
			cout<<"Pilih tiket yang ingin anda beli :"<<endl;
			cout<<"1. Group"<<endl;
			cout<<"2. Domestic diatas umur 6 tahun"<<endl;
			cout<<"3. Domestic dibawah umur 5 tahun"<<endl;
			cout<<"4. Internasional diatas umur 6 tahun"<<endl;
			cout<<"5. Internasional dibawah umur 5 tahun"<<endl;
			cout<<"Pilih 1, 2, 3, 4 atau 5 : ";
			cin>>tiket;
			cout<<endl;
			
			switch(tiket){
				case 1 : 
				cout<<"Berapa tiket yang ingin anda beli?"<<endl;
				cout<<"Masukan Jumlah Tiket: ";
				cin>>jumlah;
				cout<<endl;
				
				if(jumlah >=25){
					cout<<"Harga total tiket anda Rp3.750.000";
				}
				else if(jumlah <25){
					cout<<"Maaf,minimal pembelian kategori group adalah 25 orang";
				}
				else{
					cout<<"Error";
			}break;
			
			case 2 :
			cout<<"Harga tiket anda Rp230.000";
			break;
			
			case 3 :
			cout<<"Harga tiket anda Rp200.000";
			break;
				
			case 4 : 
			cout<<"Harga tiket anda Rp400.000";
			break;
			
			case 5 : 
			cout<<"Harga tiket anda Rp350.000";
			break;
 }break;
	
	//Hari Weekend/Libur nasional
	case 2 : 
			cout<<endl;
			cout<<"================================================"<<endl;
			cout<<"Pilih tiket yang ingin anda beli :"<<endl;
			cout<<"1. Group"<<endl;
			cout<<"2. Domestic diatas umur 6 tahun"<<endl;
			cout<<"3. Domestic dibawah umur 5 tahun"<<endl;
			cout<<"4. Internasional diatas umur 6 tahun"<<endl;
			cout<<"5. Internasional dibawah umur 5 tahun"<<endl;
			cout<<"Pilih 1, 2, 3, 4 atau 5 : ";
			cin>>tiket;
			cout<<endl;
			
			switch(tiket){
				case 1 : 
				cout<<"Berapa tiket yang ingin anda beli?"<<endl;
				cout<<"Masukan Jumlah Tiket: ";
				cin>>jumlah;
				cout<<endl;
				
				if(jumlah >=25){
					cout<<"Harga total tiket anda Rp3.750.000";
				}
				else if(jumlah <25){
					cout<<"Maaf,minimal pembelian kategori group adalah 25 orang";
				}
				else{
					cout<<"Error";
			}
			break;
			
			case 2 :
			cout<<"Harga tiket anda Rp255.000";
			break;
			
			case 3 :
			cout<<"Harga tiket anda Rp225.000";
			break;
				
			case 4 : 
			cout<<"Harga tiket anda Rp400.000";
			break;
			
			case 5 : 
			cout<<"Harga tiket anda Rp350.000";
			break;
}}}
	
	
		

			
			
			
			
