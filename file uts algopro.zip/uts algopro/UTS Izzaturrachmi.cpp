#include <iostream>
using namespace std;

int main() {
	
	int pilihantiket, jumlah, usia, asal;
	
	cout<<"	    SELAMAT DATANG DI TAMAN SAFARI BOGOR!"<<endl;
	cout<<"	============================================"<<"\n\n";
	
	//==================================PILIH JENIS TIKET=================================================
	cout<<"	Jenis Tiket: "<<"\n\n";
	cout<<"	  1. BEHIND THE SCENE TOUR"<<endl;
	cout<<"		 Syarat & Ketentuan = - Hanya berlaku hari Senin-Jumat"<<endl;
	cout<<"							  - Min 5 pax dan max 15 pax"<<endl;
	cout<<"							  - Harus melakukan reservasi & deposit terlebih dahulu"<<endl;
	cout<<"		 Fasilitas = - Mengunjungi Rumah Sakit Satwa, Ruang Nursery, Ruang Pathologi,"<<endl;
	cout<<"					   Exhibit Area, Pusat Penangkaran Gajah, Pusat Penangkaran Harimau"<<endl;
	cout<<"					   dan Genome Resource Bank"<<endl;
	cout<<"					 - Safari Journey + Pemandu + Tiket Terusan Panda"<<endl;
	cout<<"					 - Makan pilihan makan siang (termaasuk jusa atau kopi) + snack box"<<endl;
	cout<<"					 - Reservasi tempat duduk di Animal Show"<<endl;
	cout<<"					 - Disediakan tempat parkir"<<"\n\n";
	cout<<"	  2. TIKET MASUK SAFARI MALAM"<<endl;
	cout<<"		 Fasilitas = - Safari Journey"<<endl;
	cout<<"					 - 2 Pertunjukan Edukasi"<<endl;
	cout<<"					 - 24 Wahana Permainan"<<endl;
	
	cout<<"	Masukkan nomor pilihan tiket: ";
	cin>>pilihantiket;
	cout<<endl;
	
	//====================================HARGA TIKET====================================================
	if(pilihantiket == 1) {
		cout<<"	Jumlah Tiket: ";
		cin>>jumlah;
		cout<<endl;
		int total = jumlah*1000000;
		cout<<"	Harga tiket = Rp "<<total;
	}
	else if(pilihantiket == 2) {
		cout<<"	Masukkan Usia Anda: "<<endl;
		cin>>usia;
		if(usia<=5) {
			cout<<"	Pilih Kewarganegaraan Anda! "<<endl;
			cout<<"	  1. Domestik"<<endl;
			cout<<"	  2. Internasional"<<endl;
			cout<<"	Masukkan nomor pilihan: ";
			cin>>asal;
			if(asal==1){
				cout<<"	Jumlah Tiket: ";
				cin>>jumlah;
				cout<<endl;
				double total1 = jumlah*160000;
				cout<<"	Harga Tiket = Rp "<<total1;
			}
			else if(asal==2) {
				cout<<"	Jumlah Tiket: ";
				cin>>jumlah;
				cout<<endl;
				double total2 = jumlah*300000;
				cout<<"	Harga Tiket = Rp "<<total2;
			}
		}
			
		else if(usia>=6) {
			cout<<"	Pilih Kewarganegaraan Anda "<<endl;
			cout<<"	  1. Domestik"<<endl;
			cout<<"	  2. Internasional"<<endl;
			cout<<"	Masukkan nomor pilihan: ";
			cin>>asal;
			if(asal==1){
				cout<<"	Jumlah Tiket: ";
				cin>>jumlah;
				cout<<endl;
				double total3 = jumlah*180000;
				cout<<"	Harga Tiket = Rp "<<total3;
			}
			else if(asal==2) {
				cout<<"	Jumlah Tiket: ";
				cin>>jumlah;
				cout<<endl;
				double total4 = jumlah*350000;
				cout<<"	Harga Tiket = Rp "<<total4;
			}
		}
	}
	
	
	return 0;
}
