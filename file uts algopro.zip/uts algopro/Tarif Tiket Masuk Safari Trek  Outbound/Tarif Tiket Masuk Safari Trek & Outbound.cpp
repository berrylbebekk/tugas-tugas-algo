#include <iostream>
#include <string>
using namespace std;

int main () {
	int Hari, Weekend, Weekday, Domestik,Bawah5, Atas6, Bawah5Inter, Atas6Inter, Total, TotalDomestik, TotalInter;
	string Inter;
	
	cout << "=== Selamat datang di Safari Trek & Outbound ===\n\n";
	
	cout << "(Pilih Angka)";
	cout << "\n1. Weekday";
	cout << "\n2. Weekend/Hari Libur Nasional";
	cout << "\n\nDatang di Hari Weekday dan Weekend/Hari Libur Nasional? ";
	cin >> Hari;
	
	switch (Hari){ //main switch statement
		case 1: //weekday
			cout << "\nPembelian tiket minimal 25 orang";
			
			cout << "\nSilahkan masukkan data berikut:\n\n"; //data yang masuk
			cout << "Jumlah orang di bawah 5 Tahun: ";
			cin >> Bawah5;
			cout << "Jumlah orang di atas 6 Tahun: ";
			cin >> Atas6;
			
			cout << "Apakah ada turis internasional di grup anda? (y/n) ";
			cin >> Inter;
	
			if (Inter == "y"){ //jika ada turis internasional
			cout << "Masukkan data berikut:\n\n"; //data yang masuk internasional
			cout << "Jumlah orang di bawah 5 Tahun (Internasional): "; 
			cin >> Bawah5;
			cout << "Jumlah orang di atas 6 Tahun (Internasional): ";
			cin >> Atas6;
			
			TotalDomestik = (200000 * Bawah5) + (230000 * Atas6);
			TotalInter = (350000 * (Bawah5 - Bawah5Inter)) + (400000 * (Atas6 - Atas6Inter));
			
			Total = TotalDomestik + TotalInter;
			
			}
			else if (Inter == "n"){
			Total = (200000 * Bawah5) + (230000 * Atas6);
			}
			
			cout << "\n\n=== Total Pembayaran ===";
			cout << "\n\nAnda harus membayar sebesar "<<Total<<"";
			break; //end of weekday

		case 2: //weekend atau hari libur nasional
			cout << "\nPembelian tiket minimal 25 orang";
			
			cout << "\nSilahkan masukkan data berikut:\n\n"; //data yang masuk
			cout << "Jumlah orang di bawah 5 Tahun: ";
			cin >> Bawah5;
			cout << "Jumlah orang di atas 6 Tahun: ";
			cin >> Atas6;
			
			cout << "\nApakah ada turis internasional di grup anda? (y/n) ";
			cin >> Inter;
			
			if (Inter == "y"){ //jika ada turis internasional
			cout << "Masukkan data berikut:\n\n"; //data yang masuk internasional
			cout << "Jumlah orang di bawah 5 Tahun (Internasional): ";
			cin >> Bawah5;
			cout << "\nJumlah orang di atas 6 Tahun (Internasional): ";
			cin >> Atas6;
			
			TotalDomestik = (225000 * Bawah5) + (255000 * Atas6);
			TotalInter = (350000 * (Bawah5 - Bawah5Inter)) + (400000 * (Atas6 - Atas6Inter));
			
			Total = TotalDomestik + TotalInter;
			}
			
			else if (Inter == "n"){
			Total = (225000 * Bawah5) + (255000 * Atas6);
			}
			
			cout << "\n\n=== Total Pembayaran ===";
			cout << "\n\nAnda harus membayar sebesar "<<Total<<"";
			break; //end of weekend
		} //end of main switch statement
				
	
	return 0;
}
