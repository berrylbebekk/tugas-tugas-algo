#include <iostream>
#include <stdlib.h>
using namespace std;

int main (){
	string tiket;
	int jumlahgroup, tarif ,balita, dewasa, hari;
	char ulang;
	do{
	system("cls");
	cout <<"SAFARI TREK DAN OUTBOUND";
	cout <<"\n--------------------------------";
	cout <<"\n1. Weekdays (Senin- Jumat)"<<"\n2. Weekend (Sabtu-Minggu) / Holiday (Hari Libur Nasional)\n";
	cout <<"\nPILIH JENIS HARI ANDA BERKUNJUNG\t\t\t: ";
	cin >>hari;
	cout <<"Jumlah pengunjung balita (usia 5 tahun atau kurang)\t: ";
	cin >>balita;
	cout <<"Jumlah pengunjung dewasa (5 tahun ke atas)\t\t: ";
	cin >>dewasa;
	cout <<"Jenis tiket (DOMESTIC/INTERNATIONAL)\t\t\t: ";
	cin >>tiket;
	
	jumlahgroup = balita+dewasa;
	
	if (jumlahgroup>24){
		tarif = 150000*jumlahgroup;
		cout <<"Selamat! Anda mendapatkan potongan khusus group";
		cout <<"\nTarif tiket yang harus dibayar sebanyak Rp.150.000 x "<<jumlahgroup<<" = Rp."<<tarif;
	}
	else{
		switch(hari){
			case 1:
				if (tiket=="DOMESTIC"){
					tarif= (dewasa*230000)+(balita*200000);
				cout << "\nTarif tiket yang harus dibayar sebanyak : Rp."<<tarif;
				cout << "\nKET: Tarif DOMESTIC Weekdays untuk Balita("<<balita<<") dan untuk Dewasa("<<dewasa<<")";
				}
				
				else if (tiket=="INTERNATIONAL"){
					tarif= (dewasa*400000)+(balita*350000);
				cout << "\nTarif tiket yang harus dibayar sebanyak : Rp."<<tarif;
				cout << "\nKET: Tarif INTERNATIONAL Weekdays untuk Balita("<<balita<<") dan untuk Dewasa("<<dewasa<<")";
				}
				
			break;
			
			case 2:
				if (tiket=="DOMESTIC"){
					tarif= (dewasa*255000)+(balita*225000);
				cout << "\nTarif tiket yang harus dibayar sebanyak : Rp."<<tarif;
				cout << "\nKET: Tarif DOMESTIC Weekend/Holiday untuk Balita("<<balita<<") dan untuk Dewasa("<<dewasa<<")";
				}
				
				else if (tiket=="INTERNATIONAL"){
					tarif= (dewasa*400000)+(balita*350000);
				cout << "\nTarif tiket yang harus dibayar sebanyak : Rp."<<tarif;
				cout << "\nKET: Tarif INTERNATIONAL Weekend/Holiday untuk Balita("<<balita<<") dan untuk Dewasa("<<dewasa<<")";
				}
				
			break;
				
		}
	}
	cout<<"\n--------------------------------";
	cout<<"\nTarif Termasuk: Kegiatan Hiking , Wahana Outbound, SFC lunch box dan Snack box";
	cout<<"\nApakah ingin kembali ke menu awal? (y/t): ";
	cin>>ulang;
	
	}
	while (ulang != 't');
	cout <<"Terimakasih telah menggunakan jasa Safari!";
	return 0;
}
