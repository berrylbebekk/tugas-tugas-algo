#include<iostream>
using namespace std;

int main(){
	int pil, hari, harga1=1000000, tiket, bayar;
	
	cout<<"1. BEHIND THE SCENE TOUR "<<endl;
	cout<<"2. SAFARI MALAM "<<endl;
	cout<<"PILIH PAKET :";
	cin>>pil;
	
	if (pil == 1) { 
		cout << " Paket yang anda pilih adalah BEHIND THE SCENE TOUR "<<endl;
		cout << " JUMLAH TIKET : ";
		cin >>tiket;
		if(tiket <= 5) { 
			cout << "MINIMAL PEMBELIAN 5 TIKET!";
		}
		if(tiket >= 5){
			bayar=1000000*tiket;
			cout << "TOTAL PEMBAYARAN Rp "<<bayar;
		}
		}
	if (pil == 2){
		cout << "1. DOMESTIK "<<endl;
		cout << "2. INTERNATIONAL "<<endl;
		cout << "MASUKAN PILIHAN : ";
		cin >> pil;
		
		if(pil == 1){
			cout << " MASUKAN TIKET "<<endl;
			cin >>tiket;
	
		}
	}
}

