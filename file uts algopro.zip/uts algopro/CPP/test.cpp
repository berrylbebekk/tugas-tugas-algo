#include <iostream>
using namespace std;

int main() { 
  //Variabel
  char Hari_Cek, GantiHari_Cek, Buy_SafariMalam, Domestik_Cek;
  int Jumlah_Tiket,Jumlah_Tiket_Dewasa, Jumlah_Tiket_Anak, Harga_Tiket, Tipe_Tiket, Harga_Safari_Malam, Harga_Akhir;


AWAL:cout << "\n\n\n";
  cout << "===================================================================\n";
  cout << "\tTICKETING BEHIND THE SCENE TOUR dan SAFARI MALAM\n";
  cout << "===================================================================\n";
  cout << "Ingin membeli tiket apa?\n1. Behind the scene tour\n2. Safari malam\n: ";
  cin >> Tipe_Tiket;
  switch(Tipe_Tiket){
    case 1:
  cout << "Selamat datang di E-Ticketing Behind The Scene Tour Taman Safari!\n";
  cout << "Apakah hari yang ingin anda booking hari kerja? [Senin-Jumat] (y/n)\n";
  cout << ": "; cin >> Hari_Cek;
    switch(Hari_Cek){
      case 'y': cout << "\n\n\n";
        TIKET: cout << "Silahkan masukan jumlah tiket yang anda inginkan! (Min.5/Max.15 Tiket)\n: "; 
        cin >> Jumlah_Tiket;
        if (Jumlah_Tiket < 5 || Jumlah_Tiket > 15) {cout << "\nJumlah yang anda masukan tidak valid! Mohon masukan input yang valid!\n"; goto TIKET;}
        else if (Jumlah_Tiket >= 5 && Jumlah_Tiket <= 15) {
          cout << "Apakah masih ingin membeli tiket safari malam? (y/n)"; cin >> Buy_SafariMalam;
          if (Buy_SafariMalam == 'y'){goto SAFARIMALAM;}
          else{cout << "\n\nTotal Pembayaran Anda Adalah:  ";
        cout << "Rp." << Jumlah_Tiket << ".000.000\n";
        cout << "Mohon segara melakukan pembayaran, terimakasih!";}
        goto END;}
        else {goto ERROR;} 
    
      break;
      case 'n': cout << "\n\n\n";
        cout << "Mohon maaf, program Behind The Scene Tour hanya berlaku pada hari kerja. \nApakah anda ingin melakukan booking untuk hari atau tiket lain? (y/n)";
        cin >> GantiHari_Cek;
          switch (GantiHari_Cek)
          {
          case 'y':
            goto AWAL;
            break;
          case 'n':
          goto END;
          break;

          default: goto END;
          }
      break;

      default:
      ERROR: cout << "INPUT ERROR!"; goto END;
    }
  


  SAFARIMALAM:
  case 2:
  cout << "Selamat datang di E-Ticketing Safari Malam!\n";
  cout << "Apakah anda tamu domestik? (y/n) \n";
  cout << ": "; cin >> Domestik_Cek;
    switch(Domestik_Cek){
      case 'y': cout << "\n\n\n";
         cout << "Silahkan masukan jumlah tiket dewasa (>6 tahun) yang anda inginkan!\n: "; 
         cin >> Jumlah_Tiket_Dewasa;
         cout << "Silahkan masukan jumlah tiket Anak (5> tahun) yang anda inginkan!\n: "; 
         cin >> Jumlah_Tiket_Anak;

         Harga_Safari_Malam = (Jumlah_Tiket_Dewasa*180000) + (Jumlah_Tiket_Anak*160000);
         Harga_Akhir = (Jumlah_Tiket * 1000000) + Harga_Safari_Malam;

         cout << "\n\nTotal Pembayaran Anda Adalah:  ";
        cout << "Rp." << Harga_Akhir << "\n";
        cout << "Mohon segara melakukan pembayaran, terimakasih!";}
    
        




        /*
          cout << "Apakah masih ingin membeli tiket safari malam?"; cin >> Buy_SafariMalam;
          if (Buy_SafariMalam == 'y'){goto SAFARIMALAM;}
          else{cout << "\n\nTotal Pembayaran Anda Adalah:  ";
        cout << "Rp." << Jumlah_Tiket << ".000.000\n";
        cout << "Mohon segara melakukan pembayaran, terimakasih!";}}
        else {goto ERROR;} */
          








      break;
      case 'n': cout << "\n\n\n";
         cout << "Silahkan masukan jumlah tiket dewasa (>6 tahun) yang anda inginkan!\n: "; 
         cin >> Jumlah_Tiket_Dewasa;
         cout << "Silahkan masukan jumlah tiket Anak (5> tahun) yang anda inginkan!\n: "; 
         cin >> Jumlah_Tiket_Anak;

         Harga_Safari_Malam = (Jumlah_Tiket_Dewasa*350000) + (Jumlah_Tiket_Anak*300000);
         Harga_Akhir = (Jumlah_Tiket * 1000000) + Harga_Safari_Malam;

         cout << "\n\nTotal Pembayaran Anda Adalah:  ";
        cout << "Rp." << Harga_Akhir << "\n";
        cout << "Mohon segara melakukan pembayaran, terimakasih!";}

   END: cout << "\n\n\n"; return 0;
    }
    



