#include <iostream>
using namespace std;

int main() {
	int group, jumlah1, harga, hari, dom, umur, jumlah2;
	

	cout<<"---------------------------------------------"<<endl;
	cout<<" ==== SAFARI TREK DAN OUTBOUND ==== "<<endl;
	cout<<"---------------------------------------------"<<endl;
	
	
	
	cout<<"\n\n----------------------------------------------------------------"<<endl;
	cout<<" ==== GROUP MINIMAL RESERVASI 25 ORANG : RP. 150,000/Orang ==== "<<endl;
	cout<<" ====    Berlaku weekend, weekdays, dan public holiday     ==== "<<endl;
	cout<<"----------------------------------------------------------------"<<endl;
	
	

	cout<<"APAKAH ANDA MENGUNJUNGI SAFARI TREK DAN OUTBOUND BERGROUP (iya atau tidak):\n";
	cout<<"1. iya\n2. tidak \n PILIHAN (1 atau 2): " ;
	cin>>group;

	
	
	switch (group){
	case 1 :
	harga = 150000;
	cout << "\n";
	cout<<"\n\nHarga safari trek group sudah termasuk : \n Kegiatan hiking (menyusuri hutan gunung gede pangrango)\n Wahana outbound\n Pemandu \n SFC lunch box (Fried hicken, rice, teh kotak)\n Snack box";
	cout<<"\n\nJumlah tiket Dufan yang ingin dibeli :";
	cin>>jumlah1;
	if (jumlah1>=25) {cout<<"\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<harga*jumlah1;}
	else if (jumlah1<25){cout<<"\nJumlah pembelian tiket kurang, jumlah minimal pembelian tiket group adalah 25 orang";}
	break;
	
	
	case 2 :
	cout<<"\nHari apa Anda membeli tiket :\n";
	cout<<"1. WEEKDAY\n2. WEEKEND dan Holiday \n";
	cout<<"Pilihan :";
	cin>>hari;

	cout<<"\napakah anda domestic atau international :\n";
	cout<<"1. domestik \n2. Internasional\n";
	cout<<"Pilihan :";
	cin>>dom;
	
	cout<<"\nberapa umur anda :";
	cin>>umur;
	
	cout<<"\njumlah tiket yang anda beli :";
	cin>>jumlah2;
	
	
	if (hari==1 && dom==1 && umur<5){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<200000*jumlah2;}
	else if (hari==1 && dom==1 && umur>6){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<230000*jumlah2;}
 	else if (hari==1 && dom==2 && umur<5){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<350000*jumlah2;}
 	else if (hari==1 && dom==2 && umur>6){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<400000*jumlah2;}
 	
 	
 	else if (hari==2 && dom==1 && umur<5){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<225000*jumlah2;}
	else if (hari==2 && dom==1 && umur>6){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<255000*jumlah2;}
 	else if (hari==2 && dom==2 && umur<5){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<350000*jumlah2;}
 	else if (hari==2 && dom==2 && umur>6){cout << "\n\nHARGA TIKET SAFARII YANG HARUS DIBAYAR ADALAH RP. "<<400000*jumlah2;}
break;


	}



	
}
	
	
	
	
	
	
	
	

	
	


	
	
	
	
	


	
	
	
	

	


