#include <iostream>
#include <conio.h>
using namespace std;

int main(){
	
	string repeat;

do{

	system("cls");//cls digunakan untuk clear system
	
	int hari, umur, di, grup, jumlah;//input dan variabel
	
	cout<<"========================"<<endl;
	cout<<"SAFARI TREK DAN OUTBOUND"<<endl;	
	cout<<"========================"<<endl<<endl;
	
	cout<<"Selamat Datang di Safari Trek dan Outbound"<<endl;
	cout<<"Apakah anda datang secara grup?\n(jika datang secara grup masukkan angka 1, jika tidak masukkan angka 2): ";
		cin>>grup;
	if(grup==1){
	cout<<"Group: Rp.150.000/Orang"<<endl;
	cout<<"Berlaku Weekend, weekdays, & Public Holiday"<<endl<<endl<<endl;
	goto selesai;}
	
	else if(grup==2){
	cout<<"HARGA TiKET MASUK"<<endl;
	cout<<"WEEKDAY\t\t\t\t\tWEEKEND & HOLIDAY"<<endl;
	cout<<"Domestic\t\t\t\tDomestic"<<endl;
	cout<<"> 6 Tahun Rp. 230.000,-\t\t\t> 6 Tahun Rp. 255.000,-"<<endl;
	cout<<"< 5 Tahun RP. 200.000;-\t\t\t< 5 Tahun Rp. 225.000,-"<<endl<<endl;
	cout<<"International\t\t\t\tInternational"<<endl;
	cout<<"> 6 Tahun Rp. 400.000,-\t\t\t> 6 Tahun Rp. 400.000,-"<<endl;
	cout<<"> 5 Tahun Rp. 350.000,-\t\t\t> 5 Tahun Rp. 350.000,-"<<endl<<endl;
	
	cout<<"Pada hari apa anda berkunjung?"<<endl;
	cout<<"(jika weekdays, masukkan angka 1, jika weekend dan libur nasional,\n masukkan angka 2): ";
		cin>>hari;
	cout<<endl;
	
	switch(hari){
	case 1:
		cout<<"Apakah anda pengunjung domestic atau international?\n(jika domestic, masukkan angka 1, jika international, masukkan angka 2): ";
			cin>>di;
			cout<<endl;
			switch(di){
			case 1:
			cout<<"Berapa umur anda: ";
				cin>>umur;
			cout<<"Jumlah pengunjung: ";
				cin>>jumlah;
			if(umur>=6){
				int tarif = 230000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			else if(umur<=5){
				int tarif = 200000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			break;
			
			case 2:
			cout<<"Berapa umur anda: ";
				cin>>umur;
			if(umur>=6){int tarif = 400000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			else if(umur<=5){int tarif = 350000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			break;	
			}
	break;
	
	case 2:
		cout<<"Apakah anda pengunjung domestic atau international?\n(jika domestic, masukkan angka 1, jika international, masukkan angka 2): ";
			cin>>di;
			cout<<endl;
			switch(di){
			case 1:
			cout<<"Berapa umur anda: ";
				cin>>umur;
			if(umur>=6){int tarif = 255000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			else if(umur<=5){int tarif = 225000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			break;
			
			case 2:
			cout<<"Berapa umur anda: ";
				cin>>umur;
			if(umur>=6){int tarif = 400000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			else if(umur<=5){int tarif = 350000*jumlah;
			cout<<"Harga Tiket Masuk Anda adalah Rp. "<<tarif<<",-"<<endl;}
			break;	
			}
	break;	
		}	
	}
		selesai:
	cout<<endl<<"Apakah anda ingin menghitung ulang? (y/n): ";
		cin>>repeat;
	}
	
	while (repeat=="y");
	cout<<"Tekan tombol apapun untuk selesai";
	getch();
	return 0;
}
