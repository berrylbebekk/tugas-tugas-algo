#include <iostream>
#include <conio.h>
using namespace std;

int main(){
	int pil, pil1, pil2, ticket, rumus, harga, umur;
	char back;
	 
	do{
	system ("CLS");
	cout<<"\t   SELAMAT DATANG DI APLIKASI PEMBELIAN TIKET SAFARI"<<endl; //Line 10-17 Menu Utama dan Pilihan Tiket//
	cout<<"     =============================================================\n"<<endl;
	cout<<"SILAHKAN PILH JENIS TIKET "<<endl;
	cout<<"1. BEHIND THE SCENE TOUR"<<endl;
	cout<<"2. SAFARI MALAM"<<endl;
	cout<<"Pilihan anda : "; //input jenis tiket//
	cin>>pil;
	
	switch(pil){
		case 1 :
		system ("CLS");
		cout<<"\t                   BEHIND THE SCENE TOUR"<<endl; //Line 22-126 Laman bagian tiket Behind The Scene//
		cout<<"=============================================================================="<<endl;
		cout<<"Program Behind The Scene Tour merupakan salah satu Program ekslusif dari kami.";
		cout<<"\nAnda dapat belajar tentang satwa liar dari sudut pandang yang berbeda."<<endl;
		cout<<"\nSYARAT & KETENTUAN"<<endl;
		cout<<"-----------------------------------------------------------------------------"<<endl;
		cout<<"- Hanya berlaku Senin-Jumat"<<endl;
		cout<<"- Minimal 5 pax dan maksimal 15 pax"<<endl;
		cout<<"- Harus melakukan reservasi & deposit terlebih dahulu"<<endl;
		cout<<"\nFASILITAS"<<endl;
		cout<<"-----------------------------------------------------------------------------"<<endl;
		cout<<"- Mengunjungi Rumah Sakit Satwa, Ruang Nursery, Ruang Pathologi,\n  Exhibit Area, Pusat Penangkaran Gajah, Pusat Penangkaran Harimau & Genomena Resource Bank"<<endl;
		cout<<"- Safari Journey + Pemandu + Tiket Terusan Panda"<<endl;
		cout<<"- Makan Pilihan, Makan Siang (termasuk jus atau kopi) + Snack Box"<<endl;
		cout<<"- Reservasi Tempat Duduk di Animal Show"<<endl;
		cout<<"- Disediakan Tempat Parkir"<<endl;
		cout<<"\n---------------------------------------------------------------------------"<<endl;
		cout<<"Harga tiket VVIP Rp1.000.000/pax"<<endl;
		cout<<"\n---------------------------------------------------------------------------"<<endl;
		cout<<"Anda ingin membeli tiket untuk hari apa ? "<<endl; //input hari//
		cout<<"1. Senin "<<endl;
		cout<<"2. Selasa  "<<endl;
		cout<<"3. Rabu "<<endl;
		cout<<"4. Kamis"<<endl;
		cout<<"5. Jumat"<<endl;
		cout<<"Pilihan anda : ";
		cin>>pil2;
		
		switch(pil2){
		case 1 :
			harga = 1000000;
			cout<<"-----------------------------------------------------------------------------"<<endl;
			cout<<"Anda ingin membeli berapa tiket ? ";
			cin>>ticket;
				if(ticket<5){
					cout<<"Minimal Pembelian 5 Ticket"<<endl;
				goto akhir;
				} else if(ticket>=5 && ticket<=15){
					rumus = ticket*harga;
					cout<<"Total harga tiket anda adalah Rp "<<rumus<<endl;
				} else {
					cout<<"Maksimal Pembelian 15 Ticket"<<endl;
				goto akhir;
				} break; // Jika ticket <5 dan >15 maka akan langung diarahkan ke bagian akhir / kembali ke menu utama//
		case 2 :
			harga = 1000000;
			cout<<"-----------------------------------------------------------------------------"<<endl;
			cout<<"Anda ingin membeli berapa tiket ? ";
			cin>>ticket;
				if(ticket<5){
					cout<<"Minimal Pembelian 5 Ticket"<<endl;
				goto akhir;
				} else if(ticket>=5 && ticket<=15){
					rumus = ticket*harga;
					cout<<"Total harga tiket anda adalah Rp "<<rumus<<endl;
				} else {
					cout<<"Maksimal Pembelian 15 Ticket"<<endl;
				goto akhir;
				} break; // Jika ticket <5 dan >15 maka akan langung diarahkan ke bagian akhir / kembali ke menu utama//
		case 3 :
			harga = 1000000;
			cout<<"-----------------------------------------------------------------------------"<<endl;
			cout<<"Anda ingin membeli berapa tiket ? ";
			cin>>ticket;
				if(ticket<5){
					cout<<"Minimal Pembelian 5 Ticket"<<endl;
				goto akhir;
				} else if(ticket>=5 && ticket<=15){
					rumus = ticket*harga;
					cout<<"Total harga tiket anda adalah Rp "<<rumus<<endl;
				} else {
					cout<<"Maksimal Pembelian 15 Ticket"<<endl;
				goto akhir; // Jika ticket <5 dan >15 maka akan langung diarahkan ke bagian akhir / kembali ke menu utama//
				} break;
		case 4 :
			harga = 1000000;
			cout<<"-----------------------------------------------------------------------------"<<endl;
			cout<<"Anda ingin membeli berapa tiket ? ";
			cin>>ticket;
				if(ticket<5){
					cout<<"Minimal Pembelian 5 Ticket"<<endl;
				goto akhir;
				} else if(ticket>=5 && ticket<=15){
					rumus = ticket*harga;
					cout<<"Total harga tiket anda adalah Rp "<<rumus<<endl;
				} else {
					cout<<"Maksimal Pembelian 15 Ticket"<<endl;
				goto akhir; // Jika ticket <5 dan >15 maka akan langung diarahkan ke bagian akhir / kembali ke menu utama//
				} break;
		case 5 :
			harga = 1000000;
			cout<<"-----------------------------------------------------------------------------"<<endl;
			cout<<"Anda ingin membeli berapa tiket ? ";
			cin>>ticket;
				if(ticket<5){
					cout<<"Minimal Pembelian 5 Ticket"<<endl;
				goto akhir;
				} else if(ticket>=5 && ticket<=15){
					rumus = ticket*harga;
					cout<<"Total harga tiket anda adalah Rp "<<rumus<<endl;
				} else {
					cout<<"Maksimal Pembelian 15 Ticket"<<endl;
				goto akhir; 
				} break; // Jika ticket <5 dan >15 maka akan langung diarahkan ke bagian akhir / kembali ke menu utama//
		}break;
		
		
		case 2 :
		system ("CLS"); //Line 130-208 merupakan laman pembelian untuk tiket safari malam//
		cout<<"\t          SAFARI MALAM"<<endl;
		cout<<"================================================"<<endl;
		cout<<"\nFASILITAS"<<endl;
		cout<<"------------------------------------------------"<<endl;
		cout<<"- Safari Journey "<<endl;
		cout<<"- 2 Pertunjukan Edukasi"<<endl;
		cout<<"- 24 Wahana Permainan"<<endl;
		cout<<"\n---------------------------------------------"<<endl;
		cout<<"Jenis Warga Negara"<<endl;
		cout<<"1. Domestic"<<endl;
		cout<<"2. International"<<endl;
		cout<<"Pilihan Anda : "; //input pilihan kewarganegaraan//
		cin>>pil1;
		
		switch(pil1){
			case 1 : //Line 74-93 merupakan bagian tiket untuk domestik//
			cout<<"\nSilahkan Pilih Umur"<<endl;
			cout<<"1. < 5 Tahun"<<endl;
			cout<<"2. > 6 Tahun"<<endl;
			cout<<"Pilihan Anda : ";
			cin>>umur;
			
			switch(umur){
				case 1 :
				cout<<"------------------------------------------------"<<endl;
				cout<<"Harga Rp160.000 / tiket"<<endl;
				cout<<"Anda ingin memebeli berapa tiket ? ";
				cin>>pil;
				harga = 160000;
				rumus = pil*harga;
				cout<<"Anda perlu membayar sebesar Rp "<<rumus<<endl;
				break;
				
				case 2 :
				cout<<"------------------------------------------------"<<endl;
				cout<<"Harga Rp180.000 / tiket"<<endl;
				cout<<"Anda ingin memebeli berapa tiket ? ";
				cin>>pil;
				harga = 180000;
				rumus = pil*harga;
				cout<<"Anda perlu membayar sebesar Rp "<<rumus<<endl;
				break;
			} break;
			
			case 2 : //Line 100-124 merupakan bagian tiket untuk internasional//
			cout<<"\nSilahkan Pilih Umur"<<endl;
			cout<<"1. < 5 Tahun"<<endl;
			cout<<"2. > 6 Tahun"<<endl;
			cout<<"Pilihan Anda : ";
			cin>>umur;
			
			switch(umur){
				case 1 :
				cout<<"------------------------------------------------"<<endl;
				cout<<"Harga Rp350.000 / tiket"<<endl;
				cout<<"Anda ingin memebeli berapa tiket ? ";
				cin>>pil;
				harga = 350000;
				rumus = pil*harga;
				cout<<"Anda perlu membayar sebesar Rp "<<rumus<<endl;
				break;
				
				case 2 :
				cout<<"------------------------------------------------"<<endl;
				cout<<"Harga Rp300.000 / tiket"<<endl;
				cout<<"Anda ingin memebeli berapa tiket ? ";
				cin>>pil;
				harga = 300000;
				rumus = pil*harga;
				cout<<"Anda perlu membayar sebesar Rp "<<rumus<<endl;
				break;
			} break;
		}
		akhir:  //Line 100-103 merupakan line untuk menginput data 'y' untuk kembali ke laman utama//
		cout<<"-------------------------------------------------"<<endl;
		cout<<"Ingin kembali ke menu utama? \n(tekan 'y' untuk iya dan 'n' untuk tidak) : ";
    	cin>>back;
		break;	
		
	
		}  	 
	} while(back == 'y'); //perulangan//
	cout<<"\nTERIMA KASIH :)";
}
