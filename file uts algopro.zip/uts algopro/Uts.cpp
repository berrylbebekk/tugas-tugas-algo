#include <iostream>
using namespace std;

int main(){
	string hari, jenis_tiket;
	int BTHT_VVIP=1000000,domestic_6thn, domestic_5thn, international_6yo, internasional_5yo, paket;
	cout<<"=========================================================================="<<endl;
	cout<<"           Harga Tiket Behind The Scene VVIP dan Harga Tiket Safari Malam\n";
	cout<<"=========================================================================="<<endl;
		
	cout<<"PILIH HARI YANG ANDA DATANGI : ";
	cin>>hari;
	
	if (hari=="senin"||hari=="selasa"||hari=="rabu"||hari=="kamis"||hari=="jumat"){
		
	cout<<"======================================================================================================================="<<endl;
	cout<<"1. Behind The Scene Tour VVIP"<<endl;
	cout<<"2. Domestic 6 Tahun"<<endl;
	cout<<"3. Domestic 5 Tahun"<<endl;
	cout<<"4. International 6 Tahun"<<endl;
	cout<<"5.International 5 Tahun"<<endl;
	cout<<"SILAHKAN PILIH PAKET YANG ANDA INGINKAN (ANGKA) : ";
	cin>>paket;
	cout<<"======================================================================================================================="<<endl;
	

}
}