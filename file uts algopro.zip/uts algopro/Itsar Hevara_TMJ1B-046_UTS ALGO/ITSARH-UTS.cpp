#include <iostream>
#include <cmath>
using namespace std;
int main (){
	int jenis, harga, umur, hari, total, tiket;
	cout<<" --- PROGRAM TIKET BEHIND THE SCENE TOUR (VVIP)---\n\n";
	cout<<"Hari Apa Anda Akan Datang?\nKetik '1' Jika Senin-Jumat\nKetik '2' Jika Weekend, dan \nKetik '3' Jika Anda Tidak Membeli Tiket VVIP: ";
	cin>>hari;
	if(hari==1){cout<<"Berapa Tiket yang Anda Beli (Min. 5, Max. 15): ";
	cin>>tiket;
	cout<<"Total Harga Tiket VVIP Anda Adalah \t: Rp"<<1*tiket<<".000.000\n";
	}
	else if(hari==2) {cout<<"Maaf. Anda Tidak Bisa Membeli VVIP Pada Weekend\n";
	}
	else{cout<<"Baik. Terimakasih.\n";
	}
	
	cout<<"\n\n\n --- PROGRAM HARGA TIKET MASUK SAFARI MALAM ---\n\n";//UTS ITSAR HEVARA TMJ IB 046 (GENAP)
	cout<<"Dari Mana Anda Datang? \nKetik '1' Jika Turis Domestic dan Ketik '2' Jika Turis Internasional: ";
	cin>>jenis;
	cout<<"\n\nMasukan Umur Anda: ";
	cin>>umur;
	switch (jenis){
		case 1:
			if(umur>=6){harga=180;
			}
			else if(umur<=5){harga=160;
			}
			break;
			
		case 2:
			if(umur>=6){harga=350;
			}
			else if(umur<=5){harga=300;
			}
			break;
		}
	cout<<"Harga Tiket Masuk Safari Malam Anda Adalah\t: Rp"<<harga<<".000\n";
	return 0;
	
}
