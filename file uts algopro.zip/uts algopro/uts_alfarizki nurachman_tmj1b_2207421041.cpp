#include <iostream>
#include <conio.h>
using namespace std;

int main(){
	string repeat;
	do{
		system("cls");	
	cout<<"SAFARI TREK & OUTBOND"<<endl;
	cout<<"-----------------------"<<endl;
	
	int hari, umur, neg, orang, harga, total;
	awal :
	cout<<"Pilihan Hari : "<<endl;
	cout<<"1. Weekday"<<endl;
	cout<<"2. Weekend & holiday"<<endl;
	cout<<endl;
	cout<<"Pilih Hari : ";
	cin>>hari;
	
	switch(hari){
		case 1 :
			cout<<"1. International"<<endl;
			cout<<"2. Domestic"<<endl;
			cout<<"3. Safari Trek & Outbond"<<endl;
			cout<<"Pilih Jenis Tiket : ";cin>>neg;
			switch (neg){
				case 1 :
					cout<<"masukkan umur : ";cin>>umur;
					if (umur > 6){
						cout<<"harga tiket anda adalah Rp 230000"<<endl;
					}else{
						cout<<"harga tiket anda adalah Rp 200000"<<endl;
					}
					break;
				case 2 :
					cout<<"masukkan umur : ";cin>>umur;
					if (umur > 6){
						cout<<"harga tiket anda adalah Rp 400000"<<endl;
					}else{
						cout<<"harga tiket anda adalah Rp 350000"<<endl;
					}
			        break;
			    case 3 :
					cout<<"Masukkan jumlah orang : ";cin>>orang;
					harga = 150000;
					total = harga*orang;
					if (orang >= 25){
						cout<<"harga tiket anda adalah Rp "<<total<<endl;
					}else{
						cout<<"Minimal reservasi adalah 25 orang"<<endl;
					}
			        break;
	    	}
	    	break;
		case 2 :
			cout<<"1. International"<<endl;
			cout<<"2. Domestic"<<endl;
			cout<<"3. Safari Trek & Outbond"<<endl;
			cout<<"pilih kewarganegaraan : ";cin>>neg;
			switch (neg){
				case 1 :
					cout<<"masukkan umur : ";cin>>umur;
					if (umur > 6){
						cout<<"harga tiket anda adalah Rp 255000"<<endl;
					}else{
						cout<<"harga tiket anda adalah Rp 2250000"<<endl;
					}
					break;
				case 2 :
					cout<<"masukkan umur : ";cin>>umur;
					if (umur > 6){
						cout<<"harga tiket anda adalah Rp 400000"<<endl;
					}else{
						cout<<"harga tiket anda adalah Rp 350000"<<endl;
					}
			        break;
				case 3 :
					cout<<"Masukkan jumlah orang : ";cin>>orang;
					harga = 150000;
					total = harga*orang;
					if (orang >= 25){
						cout<<"harga tiket anda adalah Rp "<<total<<endl;
					}else{
						cout<<"Minimal reservasi adalah 25 orang"<<endl;
					}
			        break;	
	        }
	        break;
    }
	cout<<endl;
	cout<<"apakah anda ingin mengulang?(y/n) ";cin>>repeat;
    }while (repeat=="y");
	cout<<"\nTekan tombol apapun untuk keluar";
	getch();
	return 0;
}
