#include <iostream>

using namespace std;

int main() {
	//input
	string hari;
	int jenis, orang, usia, paket; //menggunakan int karena berisi angka
	
	cout << "TIKET SAFARI"<<endl; //judul program
	//memilih paket yang disediakan
	cout << "\n1. Safari Trek & Outbound"<<endl;
	cout << "2. Safari"<<endl;
	cout << "Silahkan pilih paket : ";
	cin >> paket;
	
	//jika paket yang dipilih merupakan paket 1, maka:
	if (paket == 1) { 
	//input pilihan hari dan juga jumlah orang 
	cout << "\nPilih hari  : ";
	cin >> hari;
	
	cout << "Jumlah orang : ";
	cin >> orang;
	//jika jumlah orang kurang dari 25, maka akan gagal karena pembelian minimal untuk 25 orang
		if (orang < 25) {
		cout << "\nMinimal pembelian tiket adalah 25 orang";
		}	
		//jika jumlah orang lebih dari 25, makan proses berlanjut dengan menghitung harga*jumlah orang dan harga langsung ditotal
		else cout << "\nTotal harga tiket anda Rp "<<150000*orang;
	}
	//jika paket yang dipilih merupakan paket 2, maka:
	else if (paket == 2) {
		//input hari
	cout << "\nPilih hari : ";
	cin >> hari;
	//jika hari adalah senin, selasa, rabu, kamis, jumat yang merupakan weekday, maka:
	if (hari=="senin"||hari=="selasa"||hari=="rabu"||hari=="kamis"||hari=="jumat") {
		//pilih yang merupakan kewarganegaraan anda, apakah domestik atau internasional
		cout << "\n1. Domestik"<<endl;
		cout << "2. Internasional"<<endl;
		
		cout << "Silahkan pilih : ";
		cin >> jenis;
		//jika anda memilih domestik, maka:
		if (jenis == 1) {
			//input usia anda dan juga jumlah orang
			cout << "\nBerapa usia anda : ";
			cin >> usia;
			cout << "Jumlah orang : ";
			cin >> orang;
			//jika usia kurang dari 5, maka:
			if (usia < 5) {
				cout << "\nTotal harga tiket anda Rp "<<200000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
			}
			//jika usia lebih dari 6, maka:
			else cout << "\nTotal harga tiket anda Rp "<<230000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
		} 
		//jika anda memilih internasional, maka:
		else if (jenis == 2) {
			//input usia anda dan juga jumlah orang
			cout << "\nBerapa usia anda : ";
			cin >> usia;
			cout << "Jumlah orang \t: ";
			cin >> orang;
			//jika usia kurang dari 5, maka:
			if (usia < 5) {
				cout << "\nTotal harga tiket anda Rp "<<350000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
			}
			//jika usia lebih dari 6, maka:
			else cout << "\nTotal harga tiket anda Rp "<<400000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
		} 
	}
	//jika hari adalah sabtu, minggu, libur yang merupakan weekday, maka:
	else if (hari == "sabtu"||hari == "minggu"||hari == "libur") {
		//pilih yang merupakan kewarganegaraan anda, apakah domestik atau internasional
		cout << "\n1. Domestic"<<endl;
		cout << "2. Internasional"<<endl;
		
		cout << "Silahkan pilih : ";
		cin >> jenis;
		
		//jika anda memilih domestik, maka:
		if (jenis == 1) {
			//input usia anda dan juga jumlah orang
			cout << "\nBerapa usia anda : ";
			cin >> usia;
			cout << "Jumlah orang : ";
			cin >> orang;
			//jika usia kurang dari 5, maka:
			if (usia <= 5) {
				cout << "\nTotal harga tiket anda Rp "<<225000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
			}
			//jika usia lebih dari 6, maka:
			else cout << "\nTotal harga tiket anda Rp "<<255000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
		} 
		//jika paket yang dipilih merupakan paket 2, maka:
		else if (jenis == 2) {
			//input usia anda dan juga jumlah orang
			cout << "\nBerapa usia anda : ";
			cin >> usia;
			cout << "Jumlah orang : ";
			cin >> orang;
			//jika usia kurang dari 5, maka:
			if (usia <= 5) {
				cout << "\nTotal harga tiket anda Rp "<<350000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
			}
			//jika usia lebih dari 6, maka:
			else cout << "\nTotal harga tiket anda Rp "<<400000*orang; //langsung muncul total harga dengan rumus harga*jumlah orang
		} 
	}
}

}
