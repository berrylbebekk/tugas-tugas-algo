#include<iostream>
using namespace std;

int main(){
		string hari, kendaraan, pil;
	int paket, tiket, bayar, harga,nama;
		cout<<"PILIH HARI : ";
	cin>>hari;
	if (hari=="senin"||hari=="selasa"||hari=="rabu"||hari=="kamis"||hari=="jumat"){
	cout<<"1. BEHIND THE SCENE TOUR 1 PACK"<<endl;
	cin>>paket;}
	else if (hari=="senin"||hari=="selasa"||hari=="rabu"||hari=="kamis"||hari=="jumat"||hari=="sabtu"||hari=="minggu"){
	cout<<"2. DOMESTIC SAFARI NIGHT > 6 TAHUN"<<endl;
	cout<<"3. DOMESTIC SAFARI NIGHT < 5 TAHUN"<<endl;
	cout<<"4. INTERNASIONAL SAFARI NIGHT > 6 TAHUN"<<endl;
	cout<<"5. INTERNASIONAL SAFARI NIGHT < 5 TAHUN"<<endl;
	cout<<"SILAHKAN PILIH PAKET YANG ANDA INGINKAN (ANGKA) : ";
	cin>>paket;}
	switch (paket){
	
		
		case 1 :
			pil = "BEHIND THE SCENE TOUR";
			harga = 1000000;
			break;
		case 2 :
			pil = "DOMESTIC SAFARI NIGHT > 6 TAHUN";
			harga = 180000;
			break;
		case 3 :
			pil = "DOMESTIC SAFARI NIGHT < 5 TAHUN ";
			harga = 160000;
			break;
		case 4 :
			pil = "INTERNASIONAL SAFARI NIGHT> 6 TAHUN";
			harga = 350000;
			break;
		case 5 :
			pil = "INTERNASIONAL SAFARI NIGHT < 5 TAHUN";
			harga = 300000;
			
			
} 	cout<<"Pilihan anda adalah "<<pil<<endl;

	cout<<"Berapa jumlah tiket yang ingin anda beli? : ";
	cin>>tiket;
	bayar=tiket*harga;
	
	if (paket==5&&tiket<5){
		cout<<"ANDA HARUS MEMBELI MINIMAL 5 TIKET!"<<endl;
	}else{
		cout<<"Harga tiket yang harus anda bayar adalah Rp. "<<bayar<<endl;
	}
	
	return 0;

}
