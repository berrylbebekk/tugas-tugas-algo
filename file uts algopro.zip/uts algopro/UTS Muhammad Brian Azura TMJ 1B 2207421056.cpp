	#include <iostream>
	using namespace std;
	
	int main(){
		
		char kembali;
		int tiket, tiket1, jumlah, total1, tiket2, domisili, hari, umur, total;
		
		//pilih tiketnya
		do{
		system("CLS");
		cout<<"\t\tTIKET MASUK TAMAN SAFARI"<<endl;
		cout<<"====================================================="<<endl;
		cout<<endl;
		
		cout<<"Pilih tiket yang anda ingin pilih"<<endl;
		cout<<"1. Behind The Scene Tour"<<endl;
		cout<<"2. Safari Malam"<<endl;
		cout<<"Pilih 1 atau 2! : ";
		cin>>tiket;
		cout<<"====================================================="<<endl;
		cout<<endl;
		
		//swtich ke tiket 1
		switch(tiket){
			case 1 : 
			cout<<"Tour ini akan menunjukkan kepada anda tentang hal-hal yang tejadi dibelakang layar"<<endl;
			cout<<"Harga VVIP Rp1.000.000/pax"<<endl;
			cout<<"Syarat dan Ketentuan: \n1. Hanya berlaku Senin-Jumat \n2. Minimal 5 pax dan Maximal 15 pax \n3. Harus melakukan reservasi dan deposit terlebih dahulu"<<endl;
			cout<<"====================================================="<<endl;
			cout<<endl;
			cout<<"Fasilitas : "<<endl;
			cout<<"1. Mengunjungi rumah Sakit Satwa, Ruang Nursery, Ruang Pathologi, Exhibit Area, Pusat Penangkaran Gajah, Pusat Penangkaran Harimau dan Genome Resouce Bank"<<endl;
			cout<<"2. Safari Journey + pemandu + Tiket terusan Panda"<<endl;
			cout<<"3. Makan Pilihan Makan siang (termasuk jus atau kopi) + Snack Box"<<endl;
			cout<<"4. Reservasi tempat duduk di Animal Show"<<endl;
			cout<<"5. Disediakan Tempat Parkir"<<endl;
			cout<<"====================================================="<<endl;
			cout<<endl;
			cout<<"Apakah Anda Ingin membeli tiket ini?"<<endl;
			cout<<"Ketik 1 jika IYA dan Ketik 2 Jika TIDAK : ";
			cin>>tiket1;
			
			
			//jumlah yang anda ingin beli
			switch(tiket1){
				case 1 : 
				cout<<"====================================================="<<endl;
				cout<<endl;
				cout<<"Berapa Banyak Tiket Yang Anda Ingin Beli : ";
				cin>>jumlah;
				total1 = 1000000*jumlah;
				if (jumlah < 5){
					cout<<"MINIMAL PEMBELIAN 5 PAX";
				}else if ((jumlah >= 5) && (jumlah <= 15)){
					cout<<"Bayar Seharga Rp "<<total1<<endl;
				}else {
					cout<<"MAKSIMAL PEMBELIAN 15 PAX";
				}
				break;
				
				case 2 :
				cout<<"====================================================="<<endl;
				cout<<endl;
				break;
			}break;
			
			
			//switch ke case 2 atau tiket 2
			case 2 :
			cout<<"Harga Tiket Safari Malam"<<endl;
			cout<<"Domestic"<<endl;
			cout<<">6 Tahun Rp180.000,-";
			cout<<"<5 Tahun Rp160.000,-"<<endl;
			cout<<"International"<<endl;
			cout<<">6 Years Old Rp350.000,-";
			cout<<"<5 Years Old Rp300.000,-";
			cout<<"====================================================="<<endl;
			cout<<endl;
			cout<<"Facility :"<<endl;
			cout<<"Safari Journey - 2 Pertunjukan Edukasi - 24 Wahana Permainan"<<endl;
			cout<<"====================================================="<<endl;
			cout<<endl;
			cout<<"Apakah Anda Ingin membeli tiket ini?"<<endl;
			cout<<"Ketik 1 jika IYA dan Ketik 2 Jika TIDAK : ";
			cin>>tiket2;
			
			//pilih domisili
			switch (tiket2){
				
				case 1 :
					cout<<"Pilih \n1.Domestic \n2.International"<<endl;
					cout<<"1 atau 2 : ";
					cin>>domisili;
					
					
					switch (domisili){
						//masukkan domisili
						case 1 : 
						cout<<"Masukkan umur anda : ";
						cin>>umur;
						if (umur > 6){
							cout<<"Harga Tiket Rp180.000,-"<<endl;
							cout<<"Masukkan jumlah tiket : ";
							cin>>jumlah;
							total = jumlah*180000;
							cout<<"Harga tiket anda Rp"<<total<<endl;
						}else {
							cout<<"Harga Tiket Rp160.000,-"<<endl;
							cout<<"Masukkan jumlah tiket : ";
							cin>>jumlah;
							total = jumlah*160000;
							cout<<"Harga tiket anda Rp"<<total<<endl;
					}break;
					case 2 : 
						cout<<"Masukkan umur anda : ";
						cin>>umur;
						if (umur > 6){
							cout<<"Harga Tiket Rp350.000,-"<<endl;
							cout<<"Masukkan jumlah tiket : ";
							cin>>jumlah;
							total = jumlah*350000;
							cout<<"Harga tiket anda Rp"<<total<<endl;
						}else {
							cout<<"Harga Tiket Rp300.000,-"<<endl;
							cout<<"Masukkan jumlah tiket : ";
							cin>>jumlah;
							total = jumlah*300000;
							cout<<"Harga tiket anda Rp"<<total<<endl;
			}break;
}
}
	}cout<<endl;
				cout<<"====================================================="<<endl;
				cout<<"Ingin kembali ke awal? \n(tekan 'y' untuk Ya dan 't' untuk Tidak) ";
				cin>>kembali;
}while (kembali == 'y');
		cout<<"\nTHANK YOU!";
}

